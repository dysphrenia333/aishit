# CppAimMinimal

Минимальная C++20-версия прототипа: один основной цикл `capture -> detect -> Kalman -> movement -> output`.

## Архитектура

- `FrameCapture`
  - `RawUdpCapture`: принимает UDP-пакеты с заголовком `uint32 frame_id + uint8 packet_id + uint8 total_packets` и собирает кадр 128×128.
  - `ObsCameraCapture`: читает OBS Virtual Camera через OpenCV `VideoCapture`.
- `YOLODetector`
  - ONNX Runtime CPUExecutionProvider.
  - Поддерживает типичные выходы YOLOv8 ONNX `[1, 84, N]` и `[1, N, 84]`.
  - Делает NMS.
- `TargetSelector`
  - Выбирает bbox, центр которого ближе всего к центру кадра.
  - Никакого SORT/Hungarian/мульти-ID.
- `KalmanFilter2D`
  - Состояние `[x, y, vx, vy]`.
  - Работает прямо в координатах 128×128.
- `MovementController`
  - `dx = (x - 64) * sensitivity_x`.
  - Low-pass: `cmd = alpha * new_cmd + (1-alpha) * old_cmd`.
  - Ограничение `max_speed`.
- `MouseController`
  - По умолчанию Windows `SendInput`.
- `GuiOverlay`
  - Dear ImGui + Win32/DX11.
  - Настройки: модель, confidence, sensitivity X/Y, smoothing, max speed, deadzone, always-on.

## Сборка через vcpkg + Visual Studio 2022

```powershell
set VCPKG_ROOT=C:\vcpkg
cmake --preset vs2022-vcpkg
cmake --build --preset release
```

Если ONNX Runtime не находится через vcpkg, укажи вручную:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 ^
  -DONNXRUNTIME_INCLUDE_DIR=C:\onnxruntime\include ^
  -DONNXRUNTIME_LIBRARY=C:\onnxruntime\lib\onnxruntime.lib
```

## Запуск

1. Положи модель в `models/model.onnx` или измени путь в `config/config.json`.
2. Запусти `CppAimMinimal.exe`.
3. Для UDP режим должен совпадать с отправителем: 128×128, RGB/RGBA raw packets.
4. Для OBS режима поставь `capture_mode = "OBS"` и нужный `obs_camera_index`.

## Важные настройки

- `sensitivity_x`, `sensitivity_y` — сила движения по осям.
- `smoothing` — инерция команды, 0 = без сглаживания.
- `max_speed` — предел относительного движения за кадр.
- `lost_timeout_ms` — сколько миллисекунд использовать Kalman prediction после потери detection.
