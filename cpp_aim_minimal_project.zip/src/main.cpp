#include "app/Application.h"

#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
    std::string configPath = "config/config.json";
    if (argc > 1) {
        configPath = argv[1];
    }

    try {
        Application app(configPath);
        return app.run();
    } catch (const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << "\n";
        return 1;
    }
}
