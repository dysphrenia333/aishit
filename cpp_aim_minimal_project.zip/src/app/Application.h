#pragma once

#include "capture/FrameCapture.h"
#include "control/MovementController.h"
#include "detector/YOLODetector.h"
#include "gui/GuiOverlay.h"
#include "output/MouseController.h"
#include "settings/Config.h"
#include "tracking/KalmanFilter2D.h"

#include <chrono>
#include <memory>

class Application {
public:
    explicit Application(std::string configPath);
    int run();

private:
    bool initialize();
    void reloadCapture();
    void reloadModel();
    bool aimActive() const;
    void processOneFrame();

    ConfigStore configStore_;
    AppConfig cfg_;

    std::unique_ptr<IFrameCapture> capture_;
    YOLODetector detector_;
    KalmanFilter2D kalman_;
    MovementController movement_;
    MouseController mouse_;
    GuiOverlay gui_;

    bool reloadModelRequested_ = false;
    bool saveRequested_ = false;
    bool exitRequested_ = false;

    std::chrono::steady_clock::time_point lastFrameTs_{};
    std::chrono::steady_clock::time_point lastMeasurementTs_{};
    bool hasTarget_ = false;
};
