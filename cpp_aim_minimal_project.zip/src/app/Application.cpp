#include "app/Application.h"

#include "tracking/TargetSelector.h"

#include <windows.h>
#include <opencv2/imgproc.hpp>

#include <algorithm>
#include <iostream>
#include <thread>

Application::Application(std::string configPath)
    : configStore_(std::move(configPath)) {}

bool Application::initialize() {
    configStore_.load(cfg_);
    cfg_.frameWidth = 128;
    cfg_.frameHeight = 128;

    reloadCapture();
    reloadModel();

    kalman_.configure(
        cfg_.kalmanMeasurementNoise,
        cfg_.kalmanPositionProcessNoise,
        cfg_.kalmanVelocityProcessNoise,
        cfg_.kalmanInitialP);
    mouse_.open(cfg_);
    gui_.init(&cfg_, &reloadModelRequested_, &saveRequested_, &exitRequested_);

    lastFrameTs_ = std::chrono::steady_clock::now();
    lastMeasurementTs_ = lastFrameTs_;
    return capture_ != nullptr;
}

void Application::reloadCapture() {
    if (capture_) {
        capture_->close();
    }
    capture_ = makeCapture(cfg_);
    if (!capture_->open(cfg_)) {
        std::cerr << "Capture open failed\n";
        capture_.reset();
    }
}

void Application::reloadModel() {
    detector_.load(cfg_.modelPath, cfg_.frameWidth, cfg_.frameHeight);
}

bool Application::aimActive() const {
    if (cfg_.alwaysOn) {
        return true;
    }
    return (GetAsyncKeyState(cfg_.holdKeyVk) & 0x8000) != 0;
}

void Application::processOneFrame() {
    if (!capture_) {
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
        return;
    }

    cv::Mat rgb;
    if (!capture_->read(rgb) || rgb.empty()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
        return;
    }

    if (rgb.cols != cfg_.frameWidth || rgb.rows != cfg_.frameHeight) {
        cv::resize(rgb, rgb, cv::Size(cfg_.frameWidth, cfg_.frameHeight));
    }

    const auto now = std::chrono::steady_clock::now();
    float dt = std::chrono::duration<float>(now - lastFrameTs_).count();
    lastFrameTs_ = now;
    dt = std::clamp(dt, 0.001f, 0.1f);

    auto boxes = detector_.detect(rgb, cfg_.confThreshold, cfg_.nmsThreshold);
    auto selected = TargetSelector::chooseClosestToCenter(boxes, cfg_.frameWidth, cfg_.frameHeight);

    cv::Point2f targetPoint{};
    bool controlValid = false;

    if (selected) {
        kalman_.predict(dt);
        targetPoint = kalman_.correct(selected->center());
        lastMeasurementTs_ = now;
        hasTarget_ = true;
        controlValid = true;
    } else if (hasTarget_ && kalman_.initialized()) {
        const auto ageMs = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastMeasurementTs_).count();
        if (ageMs <= cfg_.lostTimeoutMs) {
            targetPoint = kalman_.predict(dt);
            controlValid = true;
        } else {
            kalman_.reset();
            movement_.reset();
            hasTarget_ = false;
        }
    }

    if (!aimActive()) {
        movement_.reset();
        return;
    }

    if (controlValid) {
        targetPoint.x = std::clamp(targetPoint.x, -static_cast<float>(cfg_.frameWidth), static_cast<float>(cfg_.frameWidth * 2));
        targetPoint.y = std::clamp(targetPoint.y, -static_cast<float>(cfg_.frameHeight), static_cast<float>(cfg_.frameHeight * 2));
        const cv::Point2i cmd = movement_.compute(targetPoint, cfg_.frameWidth, cfg_.frameHeight, cfg_);
        mouse_.moveRelative(cmd.x, cmd.y);
    } else {
        movement_.reset();
    }
}

int Application::run() {
    if (!initialize()) {
        return 1;
    }

    while (!exitRequested_ && !gui_.wantsExit()) {
        gui_.newFrame();

        if (reloadModelRequested_) {
            reloadModelRequested_ = false;
            reloadModel();
        }
        if (saveRequested_) {
            saveRequested_ = false;
            configStore_.save(cfg_);
        }

        processOneFrame();
        gui_.render();
    }

    configStore_.save(cfg_);
    gui_.shutdown();
    mouse_.close();
    if (capture_) {
        capture_->close();
    }
    return 0;
}
