#include "settings/Config.h"

#include <fstream>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

ConfigStore::ConfigStore(std::string path) : path_(std::move(path)) {}

bool ConfigStore::load(AppConfig& cfg) {
    std::ifstream in(path_);
    if (!in.is_open()) {
        return false;
    }
    json j;
    try {
        in >> j;
    } catch (...) {
        return false;
    }

    cfg.modelPath = j.value("model_path", cfg.modelPath);
    cfg.captureMode = j.value("capture_mode", cfg.captureMode);
    cfg.udpBindIp = j.value("udp_bind_ip", cfg.udpBindIp);
    cfg.udpPort = static_cast<uint16_t>(j.value("udp_port", static_cast<int>(cfg.udpPort)));
    cfg.obsCameraIndex = j.value("obs_camera_index", cfg.obsCameraIndex);
    cfg.frameWidth = j.value("frame_width", cfg.frameWidth);
    cfg.frameHeight = j.value("frame_height", cfg.frameHeight);
    cfg.confThreshold = j.value("conf_threshold", cfg.confThreshold);
    cfg.nmsThreshold = j.value("nms_threshold", cfg.nmsThreshold);
    cfg.sensitivityX = j.value("sensitivity_x", cfg.sensitivityX);
    cfg.sensitivityY = j.value("sensitivity_y", cfg.sensitivityY);
    cfg.smoothing = j.value("smoothing", cfg.smoothing);
    cfg.maxSpeed = j.value("max_speed", cfg.maxSpeed);
    cfg.deadzone = j.value("deadzone", cfg.deadzone);
    cfg.kalmanMeasurementNoise = j.value("kalman_measurement_noise", cfg.kalmanMeasurementNoise);
    cfg.kalmanPositionProcessNoise = j.value("kalman_position_process_noise", cfg.kalmanPositionProcessNoise);
    cfg.kalmanVelocityProcessNoise = j.value("kalman_velocity_process_noise", cfg.kalmanVelocityProcessNoise);
    cfg.kalmanInitialP = j.value("kalman_initial_p", cfg.kalmanInitialP);
    cfg.lostTimeoutMs = j.value("lost_timeout_ms", cfg.lostTimeoutMs);
    cfg.alwaysOn = j.value("always_on", cfg.alwaysOn);
    cfg.holdKeyVk = j.value("hold_key_vk", cfg.holdKeyVk);
    cfg.outputMode = j.value("output_mode", cfg.outputMode);
    return true;
}

bool ConfigStore::save(const AppConfig& cfg) const {
    json j;
    j["model_path"] = cfg.modelPath;
    j["capture_mode"] = cfg.captureMode;
    j["udp_bind_ip"] = cfg.udpBindIp;
    j["udp_port"] = cfg.udpPort;
    j["obs_camera_index"] = cfg.obsCameraIndex;
    j["frame_width"] = cfg.frameWidth;
    j["frame_height"] = cfg.frameHeight;
    j["conf_threshold"] = cfg.confThreshold;
    j["nms_threshold"] = cfg.nmsThreshold;
    j["sensitivity_x"] = cfg.sensitivityX;
    j["sensitivity_y"] = cfg.sensitivityY;
    j["smoothing"] = cfg.smoothing;
    j["max_speed"] = cfg.maxSpeed;
    j["deadzone"] = cfg.deadzone;
    j["kalman_measurement_noise"] = cfg.kalmanMeasurementNoise;
    j["kalman_position_process_noise"] = cfg.kalmanPositionProcessNoise;
    j["kalman_velocity_process_noise"] = cfg.kalmanVelocityProcessNoise;
    j["kalman_initial_p"] = cfg.kalmanInitialP;
    j["lost_timeout_ms"] = cfg.lostTimeoutMs;
    j["always_on"] = cfg.alwaysOn;
    j["hold_key_vk"] = cfg.holdKeyVk;
    j["output_mode"] = cfg.outputMode;

    std::ofstream out(path_);
    if (!out.is_open()) {
        return false;
    }
    out << j.dump(2);
    return true;
}
